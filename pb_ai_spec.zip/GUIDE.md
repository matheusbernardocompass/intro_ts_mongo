# Guia de construção do projeto do zero

Este guia mostra a sequência para recriar a API desta pasta em um diretório vazio. Os comandos foram escritos para Bash (Linux, macOS ou WSL). O resultado final usa a mesma estrutura e as mesmas decisões de `docs/design.md`.

## 1. Preparar o diretório e o Node.js

Instale uma versão LTS do Node.js e confirme que Node e npm estão disponíveis:

```bash
node --version
npm --version
mkdir todos-demo
cd todos-demo
npm init -y
```

`npm init -y` cria o `package.json`, o manifesto que registra metadados, dependências e comandos do projeto. O arquivo gerado inicialmente usa valores genéricos; vamos ajustá-lo depois.

## 2. Instalar as dependências

Instale primeiro as bibliotecas usadas pela aplicação e depois as ferramentas de desenvolvimento:

```bash
npm install express mongoose dotenv
npm install --save-dev typescript tsx nodemon @types/node @types/express
```

- `express` registra rotas HTTP e middlewares.
- `mongoose` define o schema e conversa com MongoDB.
- `dotenv` carrega variáveis do arquivo `.env` para `process.env`.
- `typescript` verifica tipos e compila os arquivos `.ts`.
- `tsx` executa arquivos TypeScript durante o desenvolvimento.
- `nodemon` observa os arquivos indicados e reinicia o processo quando eles mudam. Neste projeto, observa `src/` e executa `tsx`.
- `@types/node` e `@types/express` fornecem tipos para as APIs do Node e do Express.

O npm grava as dependências e versões resolvidas em `package-lock.json`. Mantenha esse arquivo no controle de versão para que outras instalações reproduzam a mesma árvore de pacotes.

## 3. Configurar o projeto como ESM e definir scripts

No `package.json`, adicione `"type": "module"` e os scripts:

```json
{
  "type": "module",
  "scripts": {
    "dev": "nodemon --watch src --ext ts --exec tsx src/server.ts",
    "typecheck": "tsc --noEmit",
    "build": "tsc",
    "start": "node dist/server.js"
  }
}
```

Os scripts criam quatro caminhos claros: `dev` para editar e executar com reinício automático, `typecheck` para verificar sem gerar JavaScript, `build` para compilar e `start` para executar a compilação. O nodemon observa as mudanças; o tsx entende e executa os arquivos TypeScript.

## 4. Criar e entender o `tsconfig.json`

Crie os diretórios e o arquivo de configuração:

```bash
mkdir src
npx tsc --init
```

Substitua as opções relevantes por esta configuração concisa:

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "moduleResolution": "NodeNext",
    "rootDir": "src",
    "outDir": "dist",
    "strict": true,
    "skipLibCheck": true,
    "allowImportingTsExtensions": true,
    "rewriteRelativeImportExtensions": true,
    "esModuleInterop": true,
    "forceConsistentCasingInFileNames": true
  },
  "include": ["src/**/*.ts"]
}
```

O que as opções principais fazem:

- `target: ES2022`: gera JavaScript com recursos modernos compatíveis com Node LTS atual.
- `module` e `moduleResolution: NodeNext`: fazem o TypeScript seguir as regras ESM do Node. Neste projeto, o fonte importa diretamente `./todo.routes.ts`.
- `rootDir: src`: indica onde está o código-fonte.
- `outDir: dist`: coloca os arquivos JavaScript compilados em `dist/`.
- `strict: true`: habilita verificações rigorosas de tipo para encontrar inconsistências durante o desenvolvimento.
- `skipLibCheck: true`: evita gastar tempo verificando internamente os arquivos de tipos das dependências.
- `allowImportingTsExtensions: true`: permite escrever a extensão `.ts` nos imports locais.
- `rewriteRelativeImportExtensions: true`: reescreve imports relativos `.ts` para `.js` na saída compilada, necessária para o Node executar os arquivos de `dist/`.
- `esModuleInterop: true`: facilita imports de bibliotecas CommonJS, como o padrão de import usado pelo Express.
- `include`: limita a compilação aos arquivos TypeScript dentro de `src/`.

### Importar diretamente os arquivos `.ts`

No código-fonte, escrevemos `import { todoRouter } from './todo.routes.ts'`, apontando diretamente ao arquivo TypeScript. `allowImportingTsExtensions` permite essa extensão nos imports. `rewriteRelativeImportExtensions` troca imports relativos `.ts` por `.js` durante o build, para que Node encontre os módulos gerados em `dist/`. Em desenvolvimento, o tsx carrega os próprios arquivos `.ts`.

## 5. Criar arquivos básicos e ignorar artefatos locais

Crie `.gitignore`:

```gitignore
.env
node_modules/
dist/
```

`node_modules` pode ser reconstruído a partir do lockfile. `dist` é resultado do build. `.env` pode conter credenciais, então não deve ser versionado.

Crie `.env.example` como modelo sem segredos:

```dotenv
PORT=3000
MONGO_URI=mongodb://localhost:27017/todos_demo
```

Quem clona o projeto copia esse modelo para `.env` e ajusta as variáveis localmente:

```bash
cp .env.example .env
```

## 6. Disponibilizar MongoDB local com Docker Compose

Crie `compose.yaml`:

```yaml
services:
  mongo:
    image: mongo:8.0.5
    ports:
      - "127.0.0.1:27017:27017"
    volumes:
      - mongo_data:/data/db

volumes:
  mongo_data:
```

A tag explícita documenta a versão usada. A publicação em `127.0.0.1` restringe o acesso à máquina local. O volume nomeado mantém os dados quando o container é removido.

Inicie o banco e confira seu estado:

```bash
docker compose up -d
docker compose ps
docker compose logs mongo
```

`docker compose down` remove o container, mas mantém o volume. `docker compose down -v` também apaga os dados persistidos.

## 7. Definir o model da tarefa

Crie `src/todo.model.ts`. O schema descreve os campos persistidos e seus limites:

```ts
import { Schema, model } from 'mongoose';

const todoSchema = new Schema(
  {
    title: { type: String, required: true, trim: true, minlength: 1, maxlength: 120 },
    completed: { type: Boolean, default: false },
  },
  { timestamps: true, versionKey: false, collection: 'todos' },
);

export const Todo = model('Todo', todoSchema);
```

`timestamps` adiciona `createdAt` e `updatedAt`; `versionKey: false` remove `__v` das respostas; `collection` fixa o nome da coleção. O model oferece métodos de criação, consulta, atualização e exclusão. A validação HTTP continua necessária porque o JSON recebido não tem tipos confiáveis.

## 8. Implementar as rotas HTTP

Crie `src/todo.routes.ts` e faça um `Router` para `/todos`. A ordem de trabalho recomendada é:

1. Escrever funções pequenas para validar Content-Type, formato do corpo, campos permitidos, tipos e ID.
2. Implementar `POST /` com validação e `Todo.create`, retornando `201`.
3. Implementar `GET /` com `Todo.find().sort({ createdAt: -1, _id: -1 })`.
4. Implementar `GET /:id`, verificando o formato de 24 caracteres hexadecimais antes da consulta.
5. Implementar `PATCH /:id` com `$set`, `new: true` e `runValidators: true`; não habilitar `upsert`.
6. Implementar `DELETE /:id`, terminando com status `204` e sem corpo.

Os handlers são assíncronos: `await` espera o banco responder antes de compor a resposta HTTP. No Express 5, rejeições dos handlers async chegam ao middleware de erro. Se usar Promises com `.then()`, encaminhe erros com `.catch(next)`.

Cada erro de validação pode ser retornado no formato uniforme:

```ts
res.status(400).json({ message: 'O corpo deve ser um objeto JSON.' });
```

## 9. Configurar Express, MongoDB e inicialização

Crie `src/server.ts` nesta ordem lógica:

1. Carregue `dotenv/config` antes de consultar `process.env`.
2. Valide `MONGO_URI` e que `PORT`, se fornecida, seja um inteiro entre 1 e 65535.
3. Crie a aplicação Express e instale `express.json({ limit: '10kb' })`.
4. Monte o router em `/todos`.
5. Adicione um middleware JSON para rotas não encontradas.
6. Adicione por último o middleware de erros, que identifica JSON malformado, corpo grande, erro de validação Mongoose e falhas inesperadas.
7. Aguarde `mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 })`.
8. Só depois abra a porta HTTP com `app.listen`.

A conexão antes do `listen` evita aceitar chamadas quando o banco não está pronto. Em falha inicial, registre uma mensagem útil sem mostrar a URI e termine o processo com código 1.

## 10. Escrever exemplos e documentação de uso

Crie `requests.http` com exemplos de criação, lista, consulta, alterações parciais e exclusão. Copie o `_id` retornado pela criação para a variável `@todoId`. Inclua chamadas inválidas para demonstrar as respostas 400, 404, 413 e 415. Para a extensão REST Client do VS Code, mantenha `requests.rest.http`, o corpo de demonstração grande em `requests/payload-over-10kb.json` e a recomendação da extensão em `.vscode/extensions.json`.

No README, documente os comandos do fluxo diário:

```bash
npm install
cp .env.example .env
docker compose up -d
npm run dev
```

Depois da implementação, o README também deve ensinar os comandos de compilação (`npm run typecheck`, `npm run build`, `npm start`), as chamadas curl e a configuração de uma URI MongoDB remota.

## 11. Rodar e verificar o projeto

Com MongoDB iniciado e `.env` preenchido, execute:

```bash
npm run typecheck
npm run build
npm run dev
```

Em outro terminal, faça uma chamada de leitura:

```bash
curl -i http://localhost:3000/todos
```

Deve retornar `200` com `[]` quando ainda não há tarefas. Use os exemplos de `requests.http` ou do README para percorrer o restante do CRUD. O nodemon observa `src/**/*.ts` e reinicia a execução via tsx após alterações. Depois de validar o modo de desenvolvimento, teste a saída compilada:

```bash
npm start
```

`npm start` precisa de um build recente e de um `.env` válido. Para observar persistência, crie uma tarefa, pare a API, reinicie-a e consulte a lista. Para verificar o volume, faça `docker compose down` seguido de `docker compose up -d`; evite `down -v` durante essa demonstração.

## Estrutura final

```text
todos-demo/
├── docs/
├── src/
│   ├── server.ts
│   ├── todo.model.ts
│   └── todo.routes.ts
├── .env.example
├── .gitignore
├── .vscode/
│   └── extensions.json
├── compose.yaml
├── package.json
├── package-lock.json
├── requests.http
├── requests.rest.http
├── requests/
│   └── payload-over-10kb.json
├── tsconfig.json
└── README.md
```

O projeto desta pasta já contém esses arquivos e configurações. Este guia serve como caminho didático para entender como cada peça foi montada em sequência.
