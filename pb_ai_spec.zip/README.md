# API de tarefas (todos)

API didática em TypeScript, Node.js, Express 5 e MongoDB com Mongoose. Não há frontend; use curl ou a extensão REST Client do VS Code. A aplicação é executada pelo Node no computador; Docker Compose inicia somente o banco.

## Pré-requisitos

- Node.js 24.14.0 (LTS; versão usada nesta preparação) e npm.
- Docker com Docker Compose para usar o MongoDB local.
- Para banco remoto, uma URI MongoDB válida e acesso de rede.

## Executar localmente

```bash
npm install
cp .env.example .env
docker compose up -d
npm run dev
```

A API só abre a porta depois de conectar ao MongoDB. Se o banco ainda estiver inicializando, consulte `docker compose logs mongo` e reinicie a API quando estiver pronto. Endereço padrão: `http://localhost:3000`.

Edite `.env` para configurar `PORT` (inteiro de 1 a 65535, padrão `3000`) e `MONGO_URI` (obrigatória). Para um MongoDB remoto, altere apenas `MONGO_URI`, incluindo o nome do banco na URL, e reinicie a API. Codifique caracteres especiais em usuário e senha conforme as regras de URI. Não compartilhe credenciais.

## CRUD com curl

Crie a tarefa e copie `_id` da resposta para `<ID>` nas chamadas seguintes:

```bash
curl -i -X POST http://localhost:3000/todos \
  -H 'Content-Type: application/json' \
  -d '{"title":"Aprender TypeScript"}'
curl -i http://localhost:3000/todos
curl -i http://localhost:3000/todos/<ID>
curl -i -X PATCH http://localhost:3000/todos/<ID> \
  -H 'Content-Type: application/json' -d '{"completed":true}'
curl -i -X PATCH http://localhost:3000/todos/<ID> \
  -H 'Content-Type: application/json' -d '{"title":"Praticar Express"}'
curl -i -X DELETE http://localhost:3000/todos/<ID>
```

`requests.http` contém exemplos para qualquer extensão compatível com esse formato. `requests.rest.http` documenta o uso da extensão **REST Client** (`humao.rest-client`) do VS Code: instale a extensão no editor, abra o arquivo, envie primeiro a criação, copie o `_id` da resposta para `@todoId` e então clique em **Send Request** nas chamadas seguintes. O cenário de corpo acima de 10 KB usa o fixture `requests/payload-over-10kb.json`. O workspace recomenda a extensão em `.vscode/extensions.json`; não é necessário instalar pacote npm na aplicação.

## Build e execução compilada

```bash
npm run typecheck
npm run build
npm start
```

O TypeScript é compilado para `dist/`. No desenvolvimento, o nodemon observa mudanças em arquivos `.ts` dentro de `src/` e reinicia `tsx`, que executa o TypeScript diretamente. Os imports locais apontam explicitamente aos arquivos `.ts` do projeto. Na compilação, `rewriteRelativeImportExtensions` os reescreve para `.js`, que é a extensão gerada em `dist/`.

## MongoDB e dados

O Compose publica MongoDB somente em `127.0.0.1:27017` e mantém os dados no volume `mongo_data`. `docker compose down` para e remove o container, preservando o volume. `docker compose down -v` também apaga o volume e os dados locais.

## Roteiro da apresentação (45 min + 5 min de margem)

1. (0–5) Problema, contrato HTTP e formato da tarefa.
2. (5–12) Node.js, npm, TypeScript, tipos e build.
3. (12–19) Express, handlers, JSON e códigos HTTP.
4. (19–26) MongoDB, documentos, Mongoose, Compose e `.env`.
5. (26–38) Percorrer o CRUD com `requests.http` ou curl.
6. (38–43) Mostrar validação, ID malformado e recurso inexistente.
7. (43–45) Persistência e troca para URI remota.
8. (45–50) Perguntas e margem.

Antes da apresentação, instale dependências, baixe a imagem com `docker compose pull`, deixe a porta 3000 disponível e confirme que o MongoDB inicia. A demo é voltada a aprendizado e não inclui autenticação ou paginação.
