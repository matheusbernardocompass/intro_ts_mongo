import { Schema, model } from 'mongoose';

const todoSchema = new Schema(
  {
    title: { type: String, required: true, trim: true, minlength: 1, maxlength: 120 },
    completed: { type: Boolean, default: false },
  },
  {
    timestamps: true,
    versionKey: false,
    collection: 'todos',
  },
);

export const Todo = model('Todo', todoSchema);
