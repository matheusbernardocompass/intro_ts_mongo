import { Router, type Request, type Response, type NextFunction } from 'express';
import { Todo } from './todo.model.ts';

export const todoRouter = Router();
const validId = /^[0-9a-fA-F]{24}$/;
const allowedFields = new Set(['title', 'completed']);

function sendError(res: Response, status: number, message: string): void {
  res.status(status).json({ message });
}

function requireJson(req: Request, res: Response): boolean {
  if (!req.is('application/json')) {
    sendError(res, 415, 'Envie o corpo com Content-Type: application/json.');
    return false;
  }
  return true;
}

function validateBody(body: unknown, partial: boolean, res: Response): Record<string, unknown> | null {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    sendError(res, 400, 'O corpo deve ser um objeto JSON.');
    return null;
  }

  const input = body as Record<string, unknown>;
  const keys = Object.keys(input);
  if (keys.some((key) => !allowedFields.has(key))) {
    sendError(res, 400, 'O corpo aceita somente os campos title e completed.');
    return null;
  }
  if (partial && keys.length === 0) {
    sendError(res, 400, 'Informe ao menos um campo para atualizar.');
    return null;
  }
  if (!partial && !Object.hasOwn(input, 'title')) {
    sendError(res, 400, 'O campo title é obrigatório.');
    return null;
  }
  if (Object.hasOwn(input, 'title')) {
    if (typeof input.title !== 'string') {
      sendError(res, 400, 'Título deve ser um texto.');
      return null;
    }
    const title = input.title.trim();
    if (title.length < 1 || title.length > 120) {
      sendError(res, 400, 'Título deve ter entre 1 e 120 caracteres.');
      return null;
    }
    input.title = title;
  }
  if (Object.hasOwn(input, 'completed') && typeof input.completed !== 'boolean') {
    sendError(res, 400, 'completed deve ser booleano.');
    return null;
  }
  return input;
}

function requireId(req: Request, res: Response): boolean {
  const id = req.params.id;
  if (typeof id !== 'string' || !validId.test(id)) {
    sendError(res, 400, 'Identificador inválido.');
    return false;
  }
  return true;
}

todoRouter.post('/', (req, res, next) => {
  if (!requireJson(req, res)) return;
  const data = validateBody(req.body, false, res);
  if (!data) return;
  Todo.create(data).then((todo) => res.status(201).json(todo)).catch(next);
});

todoRouter.get('/', async (_req, res) => {
  const todos = await Todo.find().sort({ createdAt: -1, _id: -1 });
  res.json(todos);
});

todoRouter.get('/:id', async (req, res) => {
  if (!requireId(req, res)) return;
  const todo = await Todo.findById(req.params.id);
  if (!todo) return sendError(res, 404, 'Tarefa não encontrada.');
  res.json(todo);
});

todoRouter.patch('/:id', (req, res, next) => {
  if (!requireId(req, res)) return;
  if (!requireJson(req, res)) return;
  const data = validateBody(req.body, true, res);
  if (!data) return;
  Todo.findByIdAndUpdate(req.params.id, { $set: data }, { new: true, runValidators: true })
    .then((todo) => {
      if (!todo) sendError(res, 404, 'Tarefa não encontrada.');
      else res.json(todo);
    })
    .catch(next);
});

todoRouter.delete('/:id', async (req, res) => {
  if (!requireId(req, res)) return;
  const todo = await Todo.findByIdAndDelete(req.params.id);
  if (!todo) return sendError(res, 404, 'Tarefa não encontrada.');
  res.status(204).end();
});
