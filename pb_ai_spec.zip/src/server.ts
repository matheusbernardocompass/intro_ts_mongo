import 'dotenv/config';
import express, { type ErrorRequestHandler } from 'express';
import mongoose from 'mongoose';
import { todoRouter } from './todo.routes.ts';

function readConfig(): { port: number; mongoUri: string } {
  const mongoUri = process.env.MONGO_URI?.trim();
  if (!mongoUri) throw new Error('Defina MONGO_URI no arquivo .env.');

  const rawPort = process.env.PORT;
  const port = rawPort === undefined ? 3000 : Number(rawPort);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('PORT deve ser um inteiro entre 1 e 65535.');
  }
  return { port, mongoUri };
}

const app = express();
app.use(express.json({ limit: '10kb' }));
app.use('/todos', todoRouter);
app.use((_req, res) => res.status(404).json({ message: 'Rota não encontrada.' }));

const errorHandler: ErrorRequestHandler = (error: unknown, _req, res, _next) => {
  const err = error as { type?: string; name?: string };
  if (err.type === 'entity.parse.failed') {
    res.status(400).json({ message: 'JSON inválido.' });
    return;
  }
  if (err.type === 'entity.too.large') {
    res.status(413).json({ message: 'Corpo excede o limite de 10 KB.' });
    return;
  }
  if (err.name === 'ValidationError' || err.name === 'CastError') {
    res.status(400).json({ message: 'Dados da tarefa inválidos.' });
    return;
  }
  console.error('Falha inesperada ao processar requisição.');
  res.status(500).json({ message: 'Erro interno do servidor.' });
};
app.use(errorHandler);

async function start(): Promise<void> {
  const { port, mongoUri } = readConfig();
  await mongoose.connect(mongoUri, { serverSelectionTimeoutMS: 5000 });
  await new Promise<void>((resolve, reject) => {
    const server = app.listen(port, () => resolve());
    server.once('error', reject);
  });
  console.log(`API pronta na porta ${port}.`);
}

start().catch((error: unknown) => {
  if (error instanceof Error && error.message.startsWith('Defina MONGO_URI')) {
    console.error(error.message);
  } else if (error instanceof Error && error.message.startsWith('PORT')) {
    console.error(error.message);
  } else if ((error as NodeJS.ErrnoException)?.code === 'EADDRINUSE') {
    console.error('Não foi possível abrir a porta configurada: ela já está em uso.');
  } else {
    console.error('Não foi possível conectar ao MongoDB ou iniciar a API. Verifique a configuração e a disponibilidade do banco.');
  }
  process.exit(1);
});
